%% BME772 Final Project code - One signal analysis
% Names: Syed Ashemi, Aiden Van Greuning, Robert Harder
% Student IDs: 501051173, 501040587, 501042149

clear all               % clears all active variables
close all

%% STEP 1: Loading in the ECG data for all subjects and choosing S23
Subject_ECG = readtable("SubjectsECGdata.xlsx");
ECGS23 = Subject_ECG.S23;

% Intilization of length and time vector using sampling frequency
Length =  60000; 
Fs = 1000; 
Time = (1:Length)/Fs;

%% STEP 2: Preprocessing Phase using Pan-Tompkins Algorithm
% Normalization of Subject23 ECG data
S23_Normalization = abs(ECGS23)/max(abs(ECGS23));

%% Application of Notch Filter (Removal of 60Hz powerline interference)
% Coefficients of Notch Filter (a & b) using Transfer Function H(z) = 1 + 0.618z^-1 + z^-2

[Notch_b] = [1, 0.618, 1]; % Coefficient values of numerator
[Notch_a] = [1, 0, 0]; % Coefficient values of denominator

% Application of Low-Pass Filter (Removal of noise and High Frequencies)
% Coefficients of Low-Pass Filter (a & b) using Transfer Function H(z) = (1 - 2z^-6 + z^-12)/(1 -2z^-1 + z^-2)

[Low_b] = [1,0,0,0,0,0,-2,0,0,0,0,0,1]; % Coefficient values of numerator
[Low_a] = [1, -2, 1];  % Coefficient values of denominator

% Application of High-Pass Filter (Removal Baseline Drift and Low Frequencies)
% Coefficients of High-Pass Filter (a & b) using Transfer Function H(z) = (1 + 32z^-16 - 32z^-17 + z^-32)/32(1 - z^-1)

[High_b] = [-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,32,-32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1];  % Coefficient values of numerator
[High_a] = [32, -32]; % Coefficient values of denominator

% Application of Band-Pass Filter (Allows selected Frequencies and removal of unwated frequencies)
% Coefficients of Band-Pass Filter (a & b) using convolution of low and high pass

[Band_b] = conv(Low_b, High_b); % Coefficient values of numerator
[Band_a] = conv(Low_a, High_a); % Coefficient values of denominator

% Application of Derivative Filter (Amplifies High frequencies such as QRS complex)
% Coefficients of Derivative Filter (a & b) using Transfer Function H(z) = 1/8*(2 + z^-1 - z^-3 - 2z^-4) 

[Derivative_b] = [2, 1, 0, -1, -2]*(1/8); % Coefficient values of numerator
[Derivative_a] = [1, 0, 0]; % Coefficient values of denominator

% Application of Squaring (Rectifies the signal)

% Application of Moving Average Filter (Smoothens the signal by taking average through windowing method)
% Coefficients of Moving Average Filter (a & b) using Transfer Function H(z) = 1/30*((1 - z^-30)/(1 - z^-1)) 

[Moving_b] = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]; % Coefficient values of numerator
[Moving_a] = [30]; % Coefficient values of denominator


%% STEP 3: Frequency Response and Pole-Zero Diagram for different Filters
% Notch Filter
figure (1)
freqz(Notch_b, Notch_a, Fs);
title('Frequency Response of Notch Filter');
figure (2)
zplane(Notch_b, Notch_a);
title('Pole-Zero Diagram of Notch Filter');

Notch = filter(Notch_b, Notch_a, S23_Normalization);

% Low-Pass Filter
figure (3)
freqz(Low_b, Low_a, Fs);
title('Frequency Response of Low-Pass Filter');
figure (4)
zplane(Low_b, Low_a);
title('Pole-Zero Diagram of Low-Pass Filter');

Lowpass = filter(Low_b, Low_a, S23_Normalization);

% High-Pass Filter
figure (5)
freqz(High_b, High_a, Fs);
title('Frequency Response of High-Pass Filter');
figure (6)
zplane(High_b, High_a);
title('Pole-Zero Diagram of High-Pass Filter');

Highpass = filter(High_b, High_a, S23_Normalization);

% Band-Pass Filter
figure (7)
freqz(Band_b, Band_a, Fs);
title('Frequency Response of Band-Pass Filter');
figure (8)
zplane(Band_b, Band_a);
title('Pole-Zero Diagram of Band-Pass Filter');

Bandpass = filter(Band_b, Band_a, Notch);

% Derivative Filter
figure (9)
freqz(Derivative_b, Derivative_a, Fs);
title('Frequency Response of Derivative Filter');
figure (10)
zplane(Derivative_b, Derivative_a);
title('Pole-Zero Diagram of Derivative Filter');

Derivative = filter(Band_b, Band_a, Bandpass);

% Squaring
Squaring = (Derivative).^2;

% Moving Average Filter
figure (11)
freqz(Moving_b, Moving_a, Fs);
title('Frequency Response of Moving Average Filter');
figure (12)
zplane(Moving_b, Moving_a);
title('Pole-Zero Diagram of Moving Average Filter');
%%
MAF = filter(Moving_b, Moving_a, Squaring);
threshold = 6e+4;
[pks, locs, wid] = findpeaks(MAF, 'MinPeakHeight', threshold, 'MinPeakProminence', 1e+4);

% Detecting irrelevent peaks
L = find(pks > 6e+5); % Finding amplitudes that are greater than threshold
pks(L) = []; % Removes all peaks in the pks array, deleting peaks greater than threshold
locs(L) = []; % Removes related locations in the loc array
wid(L) = []; % Removes related widths in the wid array

%% STEP 4: Plot of S23 ECG signal before and after Pan-Tompkins Algorithm
% Plot 1: Original S23 ECG signal
figure (13)
plot(Time, ECGS23);
xlabel('Time (s)');
ylabel('Amplitude (mV)');
title('Orignal Plot of ECG');
xlim([0 20]);
grid on;

% Plot 2: S23 ECG signal after Notch Filtering
figure (14)
plot(Time, Notch);
xlabel('Time (s)');
ylabel('Amplitude (mV)');
title('After Notch Filtering ECG signal');
xlim([0 20]);
grid on;

% Plot 3: S23 ECG signal after Band-Pass Filtering
figure (15)
plot(Time, Bandpass)
xlabel('Time (s)');
ylabel('Amplitude (mV)');
title('After Band-Pass Filtering ECG signal');
xlim([0 20]);
grid on;

% Plot 4: S23 ECG signal after Derivative Filtering
figure (16)
plot(Time, Derivative)
xlabel('Time (s)');
ylabel('Amplitude (mV)');
title('After Derivative Filtering ECG signal');
xlim([0 20]);
grid on;

% Plot 5: S23 ECG signal after Squaring
figure (17)
plot(Time, Squaring)
xlabel('Time (s)');
ylabel('Amplitude (mV)');
title('After Squaring ECG signal');
xlim([0 20]);
grid on;

% Plot 6: S23 ECG signal after Moving Average Filtering
figure (18)
plot(Time, MAF)
xlabel('Time (s)');
ylabel('Amplitude (mV)');
title('After Moving Average Filtering ECG signal');
xlim([0 20]);
grid on;
%%
% Plot 7: S23 ECG signal after MAF with peaks highlighted
figure (19)
plot(Time, MAF);
hold on;
plot(locs/Fs, pks, 'rv', 'MarkerFaceColor', 'b'); 
xlabel('Time (s)');
ylabel('Amplitude (mV)');
title('Peaks of S23 ECG signal');
xlim([0 20]);
grid on;
hold off;
%%
% Plot comparison of Control S23 before and after Pan-Tompkins Algorithm
figure (20)
subplot(2,1,1);
plot(Time, ECGS23);
xlabel('Time (s)');
ylabel('Amplitude (mV)');
title('Diabetic S23 before filtering');
xlim([0 20]);
grid on;

subplot(2,1,2);
plot(Time, MAF)
xlabel('Time (s)');
ylabel('Amplitude (mV)');
title('Diabetic S23 after preprocessing using Pan-Tompkins Algorithm');
xlim([0 20]);
grid on;

%% STEP 5: Fast Fourier Transform of original ECG signal to frequency domain
ECGS23FT = fft(ECGS23); % Fast Fourier Transform of original ECG signal
FF = fix(length(ECGS23)/2) + 1; % Obtaining half the length of the spectrum for the one sided frequency to represent the actual frequency component
MAXFT = max(abs(ECGS23FT)); % Finding the max. value of the absolute value of the spectrum
F = [1:FF]*Fs/length(ECGS23); % Frequency axis up to fs/2 (Nyquist Frequency).
ECGSPECTRUM = 20*log10(abs(ECGS23FT)/MAXFT); % Converting magnitude spectrum to dB

% Fast Fourier Transform of Notch filtered ECG signal
Notch_Filter = designfilt('bandstopiir', 'FilterOrder', 2, 'HalfPowerFrequency1', 59, 'HalfPowerFrequency2', 61, 'SampleRate', Fs);
Notch = filter(Notch_Filter, ECGS23); 
FTNotch_ECG = fft(Notch); % Fast Fourier Transform of Notch ECG signal
maxftNotch = max(abs(FTNotch_ECG)); % Finding the max. value of the absolute value of the spectrum
SpecNotch_ECG = 20*log10(abs(FTNotch_ECG)/maxftNotch); % Converting magnitude spectrum to dB

figure (21)
subplot(2,1,1);
plot(F, ECGSPECTRUM(1:FF), 'LineWidth', 1.5, 'Color', 'r');
xlabel('Frequency (Hz)');
ylabel('Magnitude Spectrum (dB)');
title('Plot of Frequency Spectrum for S23 ECG signal before filtering');
xlim([0 100]); 
ylim([-100 10]); 
grid on;

subplot(2,1,2); 
plot(F, SpecNotch_ECG(1:FF), 'LineWidth', 1.5, 'Color', 'b');
xlabel('Frequency (Hz)');
ylabel('Magnitude Spectrum (dB)');
title('Plot of Frequency Spectrum for S23 ECG signal after Notch filtering');
xlim([0 100]); 
ylim([-100 10]); 
grid on;

%% STEP 6: Feature Analysis for Diabetic S23 to detect PQRST points
Length = 60000; 
Fs = 1000; 
Time = (1:Length)/Fs;

% Plot the Original S23 ECG Signal
figure (22)
plot(Time, ECGS23, 'b', 'LineWidth', 2);
hold on;
xlabel('Time (s)');
ylabel('Amplitude (mV)');
title('Original ECG Signal Normalized with Markings for P, Q, R, S, and T Peaks');
xlim([0 60]); 
grid on;

% To detect the R peaks on the ECG signal
[Rpeaks, Rlocs] = findpeaks(ECGS23, 'MinPeakHeight', 0.6, 'MinPeakDistance', Fs*0.6); 
plot(Time(Rlocs), Rpeaks, 'kv', 'MarkerFaceColor', 'r', 'DisplayName', 'R-peaks');

% To detect the Q and S peaks on the ECG signal
Qlocs = [];
Slocs = [];
for i = 1:length(Rlocs)
    % Detection of Q to the left of the R peak
    [Qpeak, Qloc] = min(ECGS23(max(Rlocs(i) - round(Fs*0.05), 1):Rlocs(i)));
    Qlocs = [Qlocs, Qloc + max(Rlocs(i) - round(Fs*0.05), 1) - 1];
    
    % Detection of S to the right of the R peak
    [Speak, Sloc] = min(ECGS23(Rlocs(i):min(Rlocs(i) + round(Fs*0.05), Length)));
    Slocs = [Slocs, Sloc + Rlocs(i) - 1];
end
plot(Time(Qlocs), ECGS23(Qlocs), 'kv', 'MarkerFaceColor', 'g', 'DisplayName', 'Q-peaks');
plot(Time(Slocs), ECGS23(Slocs), 'kv', 'MarkerFaceColor', 'y', 'DisplayName', 'S-peaks');

%  To detect the P and T peaks on the ECG signal
Plocs = [];
Tlocs = [];
for i = 1:length(Rlocs)
    % Detection of P to the left of the Q peak
    [Ppeak, Ploc] = max(ECGS23(max(Qlocs(i) - round(Fs*0.15), 1):Qlocs(i)));
    Plocs = [Plocs, Ploc + max(Qlocs(i) - round(Fs*0.15), 1) - 1];
    
    % Detection of T to the right of the S peak
    [Tpeak, Tloc] = max(ECGS23(Slocs(i):min(Slocs(i) + round(Fs*0.2), Length)));
    Tlocs = [Tlocs, Tloc + Slocs(i) - 1];
end
plot(Time(Plocs), ECGS23(Plocs), 'kv', 'MarkerFaceColor', 'm', 'DisplayName', 'P-peaks');
plot(Time(Tlocs), ECGS23(Tlocs), 'kv', 'MarkerFaceColor', 'c', 'DisplayName', 'T-peaks');

% Legend to show different peaks on the ECG signal
legend('Original ECG signal', 'R-peaks', 'Q-peaks', 'S-peaks', 'P-peaks', 'T-peaks');
hold off;

%% STEP 7: Spectrogram for Diabetic S23 ECG signal
Time = (0:length(ECGS23)-1)/Fs;

Length_window = 1024;  % Defining the window length (1024 samples is suitable for analyzing ECG signals)
Length_overlap = 512;  % Defining the overlap length (1024/2 = 512 samples)
number_FFT = 2048;  % Defining FFT length (2048 often used for higher frequency resolutions)

% Plotting the Spectrogram for Diabetic S23
figure (23);
spectrogram(ECGS23, Length_window, Length_overlap, number_FFT, Fs, 'yaxis');
xlabel('Time (s)');
ylabel('Frequency (Hz)');
title('Spectrogram for Diabetic S23 ECG signal');
colorbar;

clim([-150 0]);  % To get a greater colour scale
ylim([0 500]);  % 0-50Hz typically used for ECG, but we want higher frequencies as well

%% STEP 8: Determining ECG characterisitcs of Diabetic S23 
% For defining table variables and its features along with its size
Variable_Name = {'Signal', 'NumberofBeats', 'RRInterval', 'SDofRRInterval', 'AvgQRSLength', 'HR', 'MeanSTInterval', 'SDofSTInterval', 'MeanQTInterval', 'SDofQTInterval'};
Variable_Type = {'string', 'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double'};
Table_size = [1, length(Variable_Name)]; 
FeaturesofTable = table('Size', Table_size, 'VariableNames', Variable_Name, 'VariableTypes', Variable_Type);

% Data signal used is Subject 23 ECG
FeaturesofTable.Signal = 'ECGS23';
FeaturesofTable.NumberofBeats = length(locs);

% Calculation of Avg and SD for RR interval 
if length(locs) > 1
    FeaturesofTable.RRInterval = mean(diff(locs/Fs)) * 1000;  
    FeaturesofTable.SDofRRInterval = std(diff(locs/Fs)) * 1000;
else
    FeaturesofTable.RRInterval = 0;
    FeaturesofTable.SDofRRInterval = 0;
end

% Calculation of Avg QRS 
FeaturesofTable.AvgQRSLength = mean(wid/Fs) * 1000; 
% Calculation of HR
FeaturesofTable.HR = 60 / mean(diff(locs/Fs));  

% To store the S and T locations
S_locs = [];
T_locs = [];
for i = 1:length(locs) - 1
    RRinterval = (locs(i+1) - locs(i)) / Fs; 
    % Definding the window to search for S peaks after the R peaks
    R_loc = locs(i);
    S_window = R_loc + round(0.02 * Fs):R_loc + round(0.1 * Fs);  
    if max(S_window) <= length(MAF)
        [S_amp, S_idx] = min(MAF(S_window)); 
        S_locs(end+1) = S_window(1) + S_idx - 1;
    end

    % Definding the window to search for T peaks after the S peaks
    if ~isempty(S_locs)
        T_window = S_locs(end) + round(0.1 * Fs):S_locs(end) + round(0.25 * Fs);  
        if max(T_window) <= length(MAF)
            [T_amp, T_idx] = max(MAF(T_window)); 
            T_locs(end+1) = T_window(1) + T_idx - 1;
        end
    end
end

% Calculating Avg and SD of ST interval
if length(S_locs) == length(T_locs)
    STintervals = (T_locs - S_locs) / Fs; 
    FeaturesofTable.MeanSTInterval = mean(STintervals) * 1000;  
    FeaturesofTable.SDofSTInterval = std(STintervals) * 1000;   
else
    FeaturesofTable.MeanSTInterval = 0;
    FeaturesofTable.SDofSTInterval = 0;
end

% To store the Q and T locations
Q_locs = [];
QT_intervals = [];
for i = 1:length(locs)
    % Definding the window to search for Q peaks before the R peaks
    R_loc = locs(i);
    Q_window = max(1, R_loc - round(0.12 * Fs)):R_loc;  
    [Q_amp, Q_idx] = min(MAF(Q_window));
    Q_locs(end+1) = Q_window(1) + Q_idx - 1;

    % Calculating QT interval if a T peak exists 
    if i <= length(T_locs)
        QT_interval = (T_locs(i) - Q_locs(i)) / Fs; 
        QT_intervals(end+1) = QT_interval;
    end
end

% Calculating Avg and SD of QT interval
if ~isempty(QT_intervals)
    FeaturesofTable.MeanQTInterval = mean(QT_intervals) * 1000; 
    FeaturesofTable.SDofQTInterval = std(QT_intervals) * 1000;   
else
    FeaturesofTable.MeanQTInterval = 0;
    FeaturesofTable.SDofQTInterval = 0;
end

% Displaying all ECG characterisitcs for Subject 23 ECG signal in a table
disp(FeaturesofTable);


