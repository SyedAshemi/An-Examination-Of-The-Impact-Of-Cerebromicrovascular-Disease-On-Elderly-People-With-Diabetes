%% BME772 Final Project Code
% Names: Syed Ashemi, Aiden Van Greuning, Robert Harder
% Student IDs: 501051173, 501040587, 501042149

clear all               % clears all active variables
close all
% Loading in the ECG data for all subjects 
DATA = readtable("SubjectsECGdata.xlsx");
% Intilization of length and time vector using sampling frequency
Length =  60000; 
Fs = 1000; 
Time = [1:Length]/Fs;

%% Application of Pan-Tompkins Alogrithn for Control Subjects
% Control Subjects consist of S1-S13
M1_N1 = 1; % Starting index of the signal
M2_N1 = 13; % Last index of the signal
[rawECG1,filteredECG1] = ecg_filtered(DATA, M1_N1, M2_N1, Length);
M1 = M2_N1 - M1_N1 + 1;

% Plot of all control subjects ECG signal prior to filtering
for i = 1:M1
    M_string = string(i);
    figure(i);
    subplot(2,1,1);
    plot(Time,rawECG1(i,:))
    xlabel('Time (s)');
    ylabel('Amplitude (mV)');
    title('Before Filtering Control Subject ',M_string);
    axis tight;

% Plot of all control subjects ECG signal after filtering
    subplot(2,1,2);
    plot(Time, filteredECG1(i,:))
    xlabel('Time (s)');
    ylabel('Amplitude (mV)');
    title('After Preprocessing using Pan-Tompkins Algorithm for Control Subject ',M_string);
    axis tight;
end

%% Application of Pan-Tompkins Alogrithn for Diabetic Subjects
% Control Subjects consist of S14-S28
M1_N2 = 14; 
M2_N2 = 28; 
[rawECG2,filteredECG2] = ecg_filtered(DATA, M1_N2, M2_N2, Length);
M2 = M2_N2 - M1_N2 + 1;

% Plot of all diabetic subjects ECG signal prior to filtering
for i = 1:M2
    M_string = string(13+i);
    figure(13+i);
    subplot(2,1,1);
    plot(Time,rawECG2(i,:))
    xlabel('Time (s)');
    ylabel('Amplitude (mV)');
    title('Before Filtering Diabetic Subject ',M_string);
    axis tight;

% Plot of all control subjects ECG signal after filtering
    subplot(2,1,2);
    plot(Time, filteredECG2(i,:))
    xlabel('Time (s)');
    ylabel('Amplitude (mV)');
    title('After Preprocessing using Pan-Tompkins Algorithm for Diabetic Subject ',M_string);
    axis tight;
end

%% Function to get the actual ECG signal after filtering

function [rawECG,filteredECG]=ecg_filtered(DATA, M1, M2, Length)
    %% Preprocessing of ECG signals using Pan Thompkins Algorithm
    %% Notch Filter (Remove 60 Hz)
    % Coefficients of Notch Filter (a & b) using Transfer Function H(z) = 1 + 0.618z^-1 + z^-2

    [Notch_b] = [1, 0.618, 1]; % Coefficient values of numerator
    [Notch_a] = [1, 0, 0]; % Coefficient values of denominator

    %% Low-Pass Filter
    % Coefficients of Low-Pass Filter (a & b) using Transfer Function H(z) = (1 - 2z^-6 + z^-12)/(1 -2z^-1 + z^-2)

    [Low_b] = [1,0,0,0,0,0,-2,0,0,0,0,0,1]; % Coefficient values of numerator
    [Low_a] = [1, -2, 1];  % Coefficient values of denominator
    
    %% High-Pass Filter
    % Coefficients of High-Pass Filter (a & b) using Transfer Function H(z) = (1 + 32z^-16 - 32z^-17 + z^-32)/32(1 - z^-1)

    [High_b] = [-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,32,-32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1];  % Coefficient values of numerator
    [High_a] = [32, -32]; % Coefficient values of denominator

    %% Band-Pass Filter
    % Coefficients of Band-Pass Filter (a & b) using convolution of low and high pass

    [Band_b] = conv(Low_b, High_b); % Coefficient values of numerator
    [Band_a] = conv(Low_a, High_a); % Coefficient values of denominator

    %% Derivative Filter
    % Coefficients of Derivative Filter (a & b) using Transfer Function H(z) = 1/8*(2 + z^-1 - z^-3 - 2z^-4) 

    [Derivative_b] = [2, 1, 0, -1, -2]*(1/8); % Coefficient values of numerator
    [Derivative_a] = [1, 0, 0]; % Coefficient values of denominator

    %% Squaring Operator
    % Squaring = (Derivative).^2;

    %% Moving Average Filter
    % Coefficients of Moving Average Filter (a & b) using Transfer Function H(z) = 1/30*((1 - z^-30)/(1 - z^-1)) 

    [Moving_b] = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]; % Coefficient values of numerator
    [Moving_a] = [30]; % Coefficient values of denominator

    %% Designing a for loop to iterate multiple ECG subject signals    
    M = M2 - M1 + 1;
    % Intialization of matrix to store signals
    rawECG(M,Length) = 0; 
    
    % For loading and storing signals within the matrix
    for i = 1:M
        M_string = string(i);
        rawECG(i,:) = DATA.(strcat('S',M_string));
        %% Designing a Filter application for all ECG subjects
        ECG_Normalization(i,:) = abs(rawECG(i,:))/max(abs(rawECG(i,:)));
        Notch(i,:) = filter(Notch_b, Notch_a, ECG_Normalization(i,:));
        BandPass(i,:) = filter(Band_b, Band_a, Notch(i,:));
        Derivative(i,:) = filter(Derivative_b, Derivative_a, BandPass(i,:));
        Squaring(i,:) = Derivative(i,:).^2;
        filteredECG(i,:) = filter(Moving_b, Moving_b, Squaring(i,:));
    end
end
%% Feature Analysis and ECG characterisitcs of all Subjects

M1_N1 = 1; % Starting for control patients
M2_N1 = 13; % End for control patients 
M1_N2 = 14; % Starting for diabetic patients
M2_N2 = 28; % End for diabetic patients 

[rawECG1, filteredECG1] = ecg_filtered(DATA, M1_N1, M2_N1, Length);
M1 = M2_N1 - M1_N1 + 1; 

[rawECG2, filteredECG2] = ecg_filtered(DATA, M1_N2, M2_N2, Length);
M2 = M2_N2 - M1_N2 + 1;  

% The process for each control patient's ECG signal 
for i = 1:M1
    ECGsignal = filteredECG1(i, :);
    % Extracting all peaks and R locations for control patients 
    [P_peaks, Q_peaks, R_peaks, S_peaks, T_peaks, R_locs] = extract_PQRST(ECGsignal, Fs);
    % Calculating all ECG charactersitics based off peaks and R locations
    features = calculate_ecg_features(ECGsignal, R_locs, P_peaks, Q_peaks, S_peaks, T_peaks, Fs);
    disp(['Control Subject ' num2str(i)]);
    disp(features);
end

% The process for each diabetic patient's ECG signal
for i = 1:M2
    ECGsignal = filteredECG2(i, :); 
    % Extracting all peaks and R locations for diabetic patients 
    [P_peaks, Q_peaks, R_peaks, S_peaks, T_peaks, R_locs] = extract_PQRST(ECGsignal, Fs);
    % Calculating all ECG charactersitics based off peaks and R locations
    features = calculate_ecg_features(ECGsignal, R_locs, P_peaks, Q_peaks, S_peaks, T_peaks, Fs);
    disp(['Diabetic Subject ' num2str(i + M1_N2 - 1)]);
    disp(features);
end

% To locate and store the peaks of both control and diabetic patients 
function [P_peaks, Q_peaks, R_peaks, S_peaks, T_peaks, R_locs] = extract_PQRST(ECGsignal, Fs)
    [R_peaks, R_locs] = findpeaks(ECGsignal, 'MinPeakHeight', 0.6, 'MinPeakDistance', Fs * 0.6);
    
    Q_peaks = [];
    S_peaks = [];
     % Finding Q and S peaks based of R locations
    for i = 1:length(R_locs)
        % Min. window for Q peak before R peak
        [Q_peak, Q_loc] = min(ECGsignal(max(R_locs(i) - round(Fs * 0.05), 1):R_locs(i)));
        Q_peaks = [Q_peaks, Q_loc + max(R_locs(i) - round(Fs * 0.05), 1) - 1];

        % Min. window for S peak after R peak
        [S_peak, S_loc] = min(ECGsignal(R_locs(i):min(R_locs(i) + round(Fs * 0.05), length(ECGsignal))));
        S_peaks = [S_peaks, S_loc + R_locs(i) - 1];
    end
    
    P_peaks = [];
    T_peaks = [];
    % Finding P and S peaks based of R locations
    for i = 1:length(R_locs)
        % Min. window for P peak before Q peak
        [P_peak, P_loc] = max(ECGsignal(max(Q_peaks(i) - round(Fs * 0.15), 1):Q_peaks(i)));
        P_peaks = [P_peaks, P_loc + max(Q_peaks(i) - round(Fs * 0.15), 1) - 1];

         % Min. window for T peak after S peak
        [T_peak, T_loc] = max(ECGsignal(S_peaks(i):min(S_peaks(i) + round(Fs * 0.2), length(ECGsignal))));
        T_peaks = [T_peaks, T_loc + S_peaks(i) - 1];
    end
end

% To calculate and display all ECG characterisitcs on a table
function features = calculate_ecg_features(ECGsignal, R_locs, P_peaks, Q_peaks, S_peaks, T_peaks, Fs)
    Variable_Name = {'Signal', 'NumberofBeats', 'RRInterval', 'SDofRRInterval', 'AvgQRSLength', 'HR', 'MeanSTInterval', 'SDofSTInterval', 'MeanQTInterval', 'SDofQTInterval'};
    Variable_Type = {'string', 'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double'};
    features = table('Size', [1, length(Variable_Name)], 'VariableNames', Variable_Name, 'VariableTypes', Variable_Type);

    % For # of beats
    features.NumberofBeats = length(R_locs); 
    
    % For Avg and SD of RR interval
    if length(R_locs) > 1
        features.RRInterval = mean(diff(R_locs)/Fs)*1000; 
        features.SDofRRInterval = std(diff(R_locs)/Fs)*1000; 
    else
        features.RRInterval = 0;
        features.SDofRRInterval = 0;
    end
    
    % For Avg QRS length in sec 
    QRS_length = [];
    for i = 1:length(R_locs)
        QRS_length(i) = abs(Q_peaks(i) - S_peaks(i))/Fs; 
    end
    features.AvgQRSLength = mean(QRS_length)*1000; 

    % For HR 
    features.HR = 60 / mean(diff(R_locs)/Fs); 

    % For Avg and SD of ST interval 
    STintervals = (T_peaks - S_peaks)/Fs; 
    features.MeanSTInterval = mean(STintervals)*1000; 
    features.SDofSTInterval = std(STintervals)*1000; 

     % For Avg and SD of QT interval 
    QTintervals = (T_peaks - Q_peaks)/Fs; 
    features.MeanQTInterval = mean(QTintervals)*1000; 
    features.SDofQTInterval = std(QTintervals)*1000; 
end

%% Machine Learning (Logistic Regression - Cross Validation)

data = readtable('SubjectsECGdata.xlsx');

% Using ECG features calculated before to define X and Y parameters
x = data{:, 1:end};
y = [zeros(13, 1); ones(15, 1)];

% Standardization of the X parameter 
X = zscore(x);

% Utilize Principle Component Analysis (PCA), retaining only the initial main component
[coeff, score] = pca(X);
X_reduced = score(:, 1);  

% Initializing the number of folds and where the how many control and diabetic patients there are 
k = 5;
number_Control = 13;
number_Diabetic = 15;

% To register control as 0 and diabetic as 1
control_Idx = find(y == 0);
diabetic_Idx = find(y == 1);

% Randomly shuffle the indices
IdxControl = control_Idx(randperm(number_Control));
IdxDiabetic = diabetic_Idx(randperm(number_Diabetic));

% Split into k folds
control_Folds = cell(k, 1);
diabetic_Folds = cell(k, 1);
for fold = 1:k
    control_Folds{fold} = IdxControl(fold:k:end);
    diabetic_Folds{fold} = IdxDiabetic(fold:k:end);
end

% Set up arrays to hold each fold's correctness
Test_Accuracies = zeros(1, k);
Validation_Accuracies = zeros(1, k);

% Use data subsampling and cross-validation with an extremely high Lambda.
for fold = 1:k
    test_Idx = [control_Folds{fold}; diabetic_Folds{fold}];
    train_Idx = setdiff(1:length(y), test_Idx);
    train_Idx = train_Idx(randperm(length(train_Idx), floor(0.7 * length(train_Idx))));
    
    Xtrain = X_reduced(train_Idx);
    ytrain = y(train_Idx);
    Xtest = X_reduced(test_Idx);
    ytest = y(test_Idx);
    
    % Develop a regularized logistic regression model (Lambda = 1.0)
    [B, FitInfo] = lassoglm(Xtrain, ytrain, 'binomial', 'Alpha', 1, 'Lambda', 1.0);  % For Logisitc Regression
    
    % Utilize the coefficients and intercept at the designated Lambda
    B0 = FitInfo.Intercept;
    B = [B0; B];
    
    % Make a prediction for the test set
    y_predtest = round(glmval(B, Xtest, 'logit'));
    Test_Accuracies(fold) = sum(y_predtest == ytest)/numel(ytest);

    % Estimate the training set for the accuracy of the validation
    y_predval = round(glmval(B, X_train, 'logit'));
    Validation_Accuracies(fold) = sum(y_predval == ytrain)/numel(ytrain);
    
    fprintf('Fold %d Testing Accuracy: %.2f%%\n', fold, Test_Accuracies(fold) * 100);
    fprintf('Fold %d Validation Accuracy: %.2f%%\n', fold, Validation_Accuracies(fold) * 100);
end

% Determine the overall percentages for testing and validation
Testing_Percentage = mean(Test_Accuracies) * 100;
Validation_Percentage = mean(Validation_Accuracies) * 100;

fprintf('Overall Testing Accuracy (Testing Percentage): %.2f%%\n', Testing_Percentage);
fprintf('Overall Validation Accuracy (Validation Percentage): %.2f%%\n', Validation_Percentage);

%% Machine Learning (Logistic Regression - Confusion Matrix)
data = readtable('SubjectsECGdata.xlsx');

% Using ECG features calculated before to define X and Y parameters
X = data{:, 1:end};
y = [zeros(13, 1); ones(15, 1)];

% Standardization of the X parameter 
X = zscore(X);

% Initializing the number of folds
k = 5;

% To guarantee stratification, manually split the data
CV = cvpartition(length(y), 'KFold', k);

% Set up arrays to hold labels, predictions, and accuracy
Test_Accuracies = zeros(1, k);
Validation_Accuracies = zeros(1, k);
all_Predictions = [];
all_Labels = [];

% Use regularization when conducting cross-validation
lambda = 0.01;  % Can use a lower value to prevent overfitting

for fold = 1:k
    % Make test and training sets using the CVPartition as a guide
    train_Idx = training(cv, fold);
    test_Idx = test(cv, fold);
    
    % Apply PCA independently to every fold
    X_train = X(train_Idx, :);
    X_test = X(test_Idx, :);
    
    % Make sure there is no data leakage by standardizing the characteristics for the present fold
    Xtrain = zscore(X_train);
    Xtest = zscore(X_test);

    % Apply PCA to the project test and training data
    [coeff, score] = pca(Xtrain);
    X_trainpca = score(:, 1);  
    X_testpca = (Xtest - mean(Xtrain)) * coeff(:, 1);  
    [B, FitInfo] = lassoglm(X_trainpca, y(trainIdx), 'binomial', 'Alpha', 1, 'Lambda', lambda); 
    B0 = FitInfo.Intercept;
    B = [B0; B];
    
    % Make a prediction for the test set
    y_predtest = round(glmval(B, X_testpca, 'logit'));
    Test_Accuracies(fold) = sum(y_predtest == y(testIdx)) / numel(y(testIdx));

    % Estimate the training set for the accuracy of the validation
    y_pred_val = round(glmval(B, X_train_pca, 'logit'));
    Validation_Accuracies(fold) = sum(y_pred_val == y(trainIdx)) / numel(y(trainIdx));
    
    % Save the labels and predictions for the confusion matrix and ROC curve
    allPredictions = [all_Predictions; y_predtest];
    allLabels = [all_Labels; y(test_Idx)];
    
    fprintf('Fold %d Testing Accuracy: %.2f%%\n', fold, Test_Accuracies(fold) * 100);
    fprintf('Fold %d Validation Accuracy: %.2f%%\n', fold, Validation_Accuracies(fold) * 100);
end

% Determine the overall percentages for testing and validation
Testing_Percentage = mean(Test_Accuracies) * 100;
Validation_Percentage = mean(Validation_Accuracies) * 100;

fprintf('Overall Testing Accuracy (Testing Percentage): %.2f%%\n', Testing_Percentage);
fprintf('Overall Validation Accuracy (Validation Percentage): %.2f%%\n', Validation_Percentage);

% Confusion Matrix for the ultimate forecasts
confusionMatrix = confusionmat(allLabels, allPredictions);

% Calculate the sensitivity, specificity, and classification accuracy values
TP = confusionMatrix(2, 2);  
TN = confusionMatrix(1, 1); 
FP = confusionMatrix(1, 2);  
FN = confusionMatrix(2, 1);  

Sens = TP / (TP + FN);  
Spec = TN / (TN + FP);  
Class_Acc = (TP + TN) / sum(confusionMatrix(:));  

fprintf('Confusion Matrix:\n');
disp(confusionMatrix);
fprintf('Sensitivity: %.2f%%\n', Sens * 100);
fprintf('Specificity: %.2f%%\n', Spec * 100);
fprintf('Classification Accuracy: %.2f%%\n', Class_Acc * 100);

% AUC value and ROC Curve
[~, ~, ~, AUC] = perfcurve(allLabels, allPredictions, 1);
fprintf('AUC (Area Under Curve): %.2f\n', AUC);

figure;
[X_roc, Y_roc, ~, AUC] = perfcurve(allLabels, allPredictions, 1);
plot(X_roc, Y_roc, 'b-', 'LineWidth', 2);
xlabel('False Positive Rate');
ylabel('True Positive Rate');
title(['Receiver Operating Characteristic (ROC) Curve - AUC = ' num2str(AUC)]);
legend(['AUC = ' num2str(AUC)], 'Location', 'Best');
grid on;

% Confusion Matrix
figure;
confusionchart(allLabels, allPredictions);
title('Confusion Matrix');

